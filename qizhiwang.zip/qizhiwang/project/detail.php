<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link type="text/css" rel="stylesheet" href="css/main.css" />
</head>

<body>
<div class="total">
        <div class="headerBar">
            <div class="topBar">
                <div class="comWith">
                    <div class="fl">
                        <img src="images/icon/xing.gif"  />
                        <a href="#" class="collection">收藏启智网</a>
                    </div>
                    <div class="fr">
                        欢迎来到启智网！<a href="#">登录</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">用户注册</a>
                    </div> 
                </div>
            </div> 
            <div class="logoBar">
                    <div class="logo fl"><img src="images/logo.png" alt="启智网"/></a>
                    </div>
                    <div class="search_box f1">
                        <input type="text" class="search_text" />
                        <input type="button" value="搜索" class="search_btn" />
                    </div>
                    <ul class="nav-ul fl">
                        <li><a href="#">首页</a></li>
                        <li><a href="#">男教师</a></li>
                        <li><a href="#">女教师</a></li>
                        <li><a href="#">平台介绍</a></li>
                        <li><a href="#">家长帮助</a></li>
                    </ul>          
        </div>
    </div>
    <div class="grey">
        <div class="userPosition">
            <strong><a href="#">首页</a></strong>
            <span>&nbsp;&gt;&nbsp;</span>
            <a href="#">教师</a>
            <span>&nbsp;&gt;&nbsp;</span>
            <a href="#">高中</a>
            <span>&nbsp;&gt;&nbsp;</span> 
            <em>胡心专</em>       
        </div>
        <div class="description_info">
        	<div class="leftArea">
            	<div class="description_imgs">
            		<div class="big">
                    	<img src="images/teacher/t1.jpg" alt="胡心专" />
                    </div>
                    <div>
                        <ul class="des_simg">
                            <li><a href="#"><img src="#" alt="" /></a></li>
                            <li><a href="#"><img src="#" alt="" /></a></li>
                            <li><a href="#"><img src="#" alt="" /></a></li>
                            <li><a href="#"><img src="#" alt="" /></a></li>
                        </ul>
                    </div>
                 </div>
             </div>
             <div class="rightArea">
             	<table>
                	<tr>
                    	<td colspan="2"><h2>胡老师&nbsp;&nbsp;&nbsp;&nbsp;金牌名师</h2></td>
                    </tr>  
                	<tr>
                    	<td colspan="2" class="jieshao">&nbsp;&nbsp;&nbsp;&nbsp;胡心专，毕业于燕山大学计算机应用专业，现主要研究电子商务物流、旅游电子商务等课题。主讲jsp编程技术、网页设计与制作、C语言程序设计、电子商务网站开发与管理、电子商务专业英语等课程。迄今已在包括《企业经济》、《商业时代》、《江苏商论》等期刊发表学术论文9篇;主持或参国家与省市级科研项目6余项。</td>
                    </tr>                                   
                	<tr>
                    	<td width="114">最高学历：</td>
                        <td width="544">博士</td>
                    </tr>
                    <tr>
                    	<td>毕业院校：</td>
                        <td>燕山大学</td>
                    </tr>
                    <tr>
                    	<td>所学专业：</td>
                        <td>计算机应用专业</td>
                    </tr>
                    <tr>
                    	<td>授课方式：</td>
                        <td>老师上门</td>
                    </tr>
                    <tr>
                    	<td>授课区域：</td>
                        <td>朝阳  海淀  东城  西城  丰台  通州  石景山</td>
                    </tr> 
                    <tr>
                    	<td>授课方式：</td>
                        <td>老师上门</td>
                    </tr>                                                                               
                    <tr>
                    	<td>教学特点：</td>
                        <td><span>富有情感型</span><span>热情开朗型</span></td>
                    </tr>                    
                    <tr>
                    	<td>老师关键词：</td>
                        <td><span>启发</span><span>鼓励</span><span>热爱</span></td>
                    </tr>
                    <tr>
                    	<td>擅长学生类型：</td>
                        <td><span>苦学无用型</span><span>基础薄弱型</span></td>
                    </tr>    
                    <tr>
						<td colspan="2" ><div class="buy"><a herf="#"><img src="images/icon/yuyue.png" /></a></div></td>
                    </tr>               
                </table>     
             </div>
        </div>
        <div class="footer">
        	<img src="images/f1.JPG" class="img_a"/>
            <img src="images/f2.jpg" class="img_b"/>
        </div>
    </div>
</body>
</html>