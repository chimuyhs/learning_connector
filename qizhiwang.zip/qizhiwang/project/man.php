<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link type="text/css" rel="stylesheet" href="css/main.css" />
<link type="text/css" rel="stylesheet" href="css/tab.css" />
<script src="js/jquery-1.3.1.js" type="text/javascript"></script>
<script src="js/tab.js"type="text/javascript"></script>

</head>

<body>
<div class="total">
        <div class="headerBar">
            <div class="topBar">
                <div class="comWith">
                    <div class="fl">
                        <img src="images/icon/xing.gif"  />
                        <a href="#" class="collection">收藏启智网</a>
                    </div>
                    <div class="fr">
                        欢迎来到启智网！<a href="#">登录</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="#">用户注册</a>
                    </div> 
                </div>
            </div> 
         </div>
         <div class="midle">
         <div class="tab_show">
            <table width="1200" border="0" cellpadding="0" cellspacing="0">
                <tr>
                    <td  height="112" background="images/bg3.jpg">&nbsp;</td>
                </tr>
                <tr>
                    <td>
                    <table width="100%" height="38" border="0" cellpadding="0" cellspacing="0" background="images/link.jpg">
                        <tr>
                            <td width="193" align="center" valign="middle">
                            <b><?php echo date("Y-m-d");?></b></td>
                            <td width="101" align="center" valign="middle"><a href="index.php" class="a">返回首页</a></td>
                            <td width="102" align="center" valign="middle"><a href="#">查询教师</a></td>
                            <td width="102" align="center" valign="middle"><a href="#">查询教师</a></td>
                            <td width="102" align="center" valign="middle"><a href="#">查询教师</a></td>
                        </tr>
                    </table>
                    </td>
                </tr>
            </table>
            <table width="900" height="200" border="0" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" valign="middle">
            <?php
            include_once("conn.php");
            ?>
            <table width="98%"  border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF" bgcolor="#CCCCCC">
              <tr>
                <td width="5%" height="25" align="center" >id</td>
                <td width="30%" align="center" >教师名</td>
                <td width="10%" align="center" >授课价格</td>
                <td width="20%" align="center" >授课方式</td>
                <td width="10%" align="center" >教学特点</td>
                <td width="10%" align="center" >操作</td>
              </tr>
            <?php
                $pagesize = 3 ;									
                $sqlstr = "select * from tb_demo02 order by id";
                $total = mysqli_query($conn,$sqlstr);
                $totalNum = mysqli_num_rows($total);					
                $pagecount = ceil($totalNum/$pagesize);						
                (!isset($_GET['page']))?($page = 1):$page = $_GET['page'];			
                ($page <= $pagecount)?$page:($page = $pagecount);
                $f_pageNum = $pagesize * ($page - 1);							
                $sqlstr1 = $sqlstr." limit ".$f_pageNum.",".$pagesize;
                $result = mysqli_query($conn,$sqlstr1);								
                while ($rows = mysqli_fetch_array($result)){									
            ?>
              <tr>
                <td width="5%" height="25" align="center" bgcolor="#FFFFFF"><?php echo $rows[0];?></td>
                <td width="30%" align="center" bgcolor="#FFFFFF" ><?php echo $rows[1];?></td>
                <td width="10%" align="center" bgcolor="#FFFFFF" ><?php echo $rows[2];?></td>
                <td width="20%" align="center" bgcolor="#FFFFFF" ><?php echo $rows[3];?></td>
                <td width="10%" align="center" bgcolor="#FFFFFF" ><?php echo $rows[4];?></td>
                <td width="10%" align="center" bgcolor="#FFFFFF" >操作</td>
              </tr>
            <?php	
                }
            ?>
              <tr>
                <td height="25" colspan="6" align="left" bgcolor="#FFFFFF">&nbsp;&nbsp;
            <?php
                echo "共".$totalNum."本图书&nbsp;&nbsp;";
                echo "第".$page."页/共".$pagecount."页&nbsp;&nbsp;";
                if($page!=1){
                    echo "<a href='?page=1'>首页</a>&nbsp;";
                    echo "<a href='?page=".($page-1)."'>上一页</a>&nbsp;&nbsp;";
                }else{
                    echo "首页&nbsp;上一页&nbsp;&nbsp;";
                }
                if($page!=$pagecount){
                    echo "<a href='?page=".($page+1)."'>下一页</a>&nbsp;";
                    echo "<a href='?page=".$pagecount."'>尾页</a>&nbsp;&nbsp;";
                }else{
                    echo "下一页&nbsp;尾页&nbsp;&nbsp;";
                }
            ?>
                </td>
              </tr>
            </table>
             </td>
                </tr>
            </table>
      </div>
      <div class="tab">
        <div class="tab_menu">
            <ul>
                <li class="selected">网站公告</li>
                <li>新闻报道</li>
            </ul>
        </div>
        <div class="tab_box">
            <div>
                <a href="#">【公告】关于整顿老师作弊行为</a><br />
                <a href="#">【公告】关于整顿老师作弊行为</a><br />
                <a href="#">【公告】关于整顿老师作弊行为</a><br />
                <a href="#">【公告】关于整顿老师作弊行为</a><br />
            </div>
            <div class="hide">
                <a href="#">【启智教育】启智网与燕山大学合作</a><br />   
                <a href="#">【启智教育】启智网与燕山大学合作</a><br />  
                <a href="#">【启智教育】启智网与燕山大学合作</a><br />  
                <a href="#">【启智教育】启智网与燕山大学合作</a><br />      
            </div>
	  </div>
      </div>
        <div class="footer">
        	<img src="images/f1.JPG" class="img_a"/>
            <img src="images/f2.jpg" class="img_b"/>
        </div>
</div>
</div>
</body>
</html>