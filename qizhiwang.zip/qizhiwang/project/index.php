<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link type="text/css" rel="stylesheet" href="css/main.css" />
<script src="js/slide.js" type="text/javascript"></script>
</head>

<body>
<div class="total">
    <div class="headerBar">
        <div class="topBar">
             <div class="fl">
                  <img src="images/icon/xing.gif"  />
                  <a href="#" class="collection">收藏启智网</a>
             </div>
             <div class="fr">
                  欢迎来到启智网！<a href="login.php">登录</a>&nbsp;&nbsp;&nbsp;&nbsp;<a href="zhuce.html">用户注册</a>
             </div> 
        </div> 
        <div class="logoBar">
                <div class="logo fl"><img src="images/logo.png" alt="启智网"/>
                </div>
                <div class="search_box f1">
                    <input type="text" class="search_text" />
                    <input type="button" value="搜索" class="search_btn" />
                </div>
                <ul class="nav-ul fl">
                <li><a href="#">首页</a></li>
                <li><a href="#">男教师</a></li>
                <li><a href="#">女教师</a></li>
                <li><a href="#">平台介绍</a></li>
                <li><a href="#">家长帮助</a></li>
            	</ul>            
         </div>
    </div>
    <div class="banner">
		<div class="shopClass">
            	<ul class="kind_ul">
                	<li class="l_menu">
                    	<h2>全部课程分类</h2>     
                    </li>
                    <br />
                    <li class="l_menu">
                    	<h4>小学、小升初</h4>     
                    </li>
                    <li class="l_menu">
                    	<a href="#">数学</a>
                        <span class="menu_line">/</span>
                        <a href="#">语文</a>
                        <span class="menu_line">/</span>
                        <a href="#">英语</a>
                    </li>
                    <br />        
                    <li class="l_menu">
                    	<h4>初中、中考</h4>     
                    </li>
                    <li class="l_menu">
                    	<a href="#">数学</a>
                        <span class="menu_line">/</span>
                        <a href="#">化学</a>
                        <span class="menu_line">/</span>
                        <a href="#">语文</a>
                        <span class="menu_line">/</span>
                        <a href="#">物理</a>         
                    </li>
                    <br />
                    <li class="l_menu">
                    	<h4>高中、高考</h4>     
                    </li>
                    <li class="l_menu">
                    	<a href="#">数学</a>
                        <span class="menu_line">/</span>
                        <a href="#">物理</a>
                        <span class="menu_line">/</span>
                        <a href="#">化学</a>
                        <span class="menu_line">/</span>
                        <a href="#">英语</a>         
                    </li>
                    <br />
                    <li class="l_menu">
                    	<h4>特色课程</h4>     
                    </li>
                    <li class="l_menu">
                    	<a href="#">计算机</a>
                        <span class="menu_line">/</span>
                        <a href="#">体育</a>
                        <span class="menu_line">/</span>
                        <a href="#">音乐</a>
                        <span class="menu_line">/</span>
                        <a href="#">美术</a>         
                    </li>
                </ul>
            </div>
            <div id="focusViwer">
                <div id="imgADPlayer"></div> 
                <script> 
                    PImgPlayer.addItem( "<a href='detail.php' target=_blank style=color:#000;text-decoration:none;>燕山大学金牌名师：胡老师</a>", "detail.php","images/teacher/t1.jpg"); 		
                    PImgPlayer.addItem( "<a href=# target=_blank style=color:#000;text-decoration:none;>燕山大学金牌名师：王老师</a>", "#", "images/teacher/t4.jpg"); 		
                    PImgPlayer.addItem( "<a href=# target=_blank style=color:#000;text-decoration:none;>燕山大学金牌名师：宓老师</a>", "#", "images/teacher/t5.jpg"); 		
                    PImgPlayer.addItem( "<a href=# target=_blank style=color:#000;text-decoration:none;>燕山大学金牌名师：王老师</a>", "#", "images/teacher/t6.jpg"); 
                    PImgPlayer.addItem( "<a href=# target=_blank style=color:#000;text-decoration:none;>燕山大学金牌名师：刘老师</a>", "#", "images/teacher/t8.jpg"); 	
                    PImgPlayer.init( "imgADPlayer",600, 355+24 );   
                </script>
            </div>
            <div class="img_right">
            	<img src="images/banji.jpg" />
            </div>
        </div>
    <div class="x_teacher">
    	<div class="title"><h3>高中·高考</h3></div>
    	<div class="kuang">
            <img src="images/teacher/g1.jpg" class="img_teacher"/>
            <p class="name"><b>张老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/g2.jpg" class="img_teacher"/>
            <p class="name"><b>朱老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/g3.jpg" class="img_teacher"/>
            <p class="name"><b>杨老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/g4.jpg" class="img_teacher"/>
            <p class="name"><b>张老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
    </div>
        <div class="x_teacher">
    	<div class="title"><h3>初中·中考</h3></div>
    	<div class="kuang">
            <img src="images/teacher/c1.jpg" class="img_teacher"/>
            <p class="name"><b>赵老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/c2.jpg" class="img_teacher"/>
            <p class="name"><b>贾老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/c3.jpg" class="img_teacher"/>
            <p class="name"><b>郭老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/c4.jpg" class="img_teacher"/>
            <p class="name"><b>罗老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
    </div>
        <div class="x_teacher">
    	<div class="title"><h3>小学·小升初</h3></div>
    	<div class="kuang">
            <img src="images/teacher/x1.jpg" class="img_teacher"/>
            <p class="name"><b>张老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/x2.jpg" class="img_teacher"/>
            <p class="name"><b>陈老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/x3.jpg" class="img_teacher"/>
            <p class="name"><b>马老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
        <div class="kuang">
            <img src="images/teacher/x4.jpg" class="img_teacher"/>
            <p class="name"><b>杨老师</b></p>
            <div class="w_ban">数学<em>/</em>19年教龄</div>
            <p class="cent"><em>￥400</em>&nbsp;&nbsp;元/时</p>
        </div>
    </div>
    <div class="footer">
        	<img src="images/f1.JPG" class="img_a"/>
            <img src="images/f2.jpg" class="img_b"/>
    </div>
	</div>
</div>	
</body>
</html>