<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
<link type="text/css" rel="stylesheet" href="css/login.css">
<script src="js/yanzhengma.js" type="text/javascript"></script>
</head>

<body onload="createCode()">
	<div class="denglu_top">
    	<div class="top_left"><img src="images/logo.png"/></div>
        <div class="top_right"><p>欢迎登录启智网</p></div>
    </div>
    <div class="denglu_box">
        <div class="dl_left">
            <img src="images/tuanhuo.jpg" />
        </div>
        <div class="dl_right">
        <form id="form1" method="post" action="zhucecheck.php">
            <table height="216">
                <tr>
                    <td width="149">用户名</td>
                    <td><input type="text" name="username" /></td>
                </tr>
                <tr>
                    <td>密码</td>
                    <td><input type="password" name="password"  /></td>
                </tr>
                <tr>
                    <td>确认密码</td>
                    <td><input type="password" name="confirm"  /></td>
                </tr>
                <tr>
                    <td>验证码</td>
                    <td><input type="text" id="inputCode" name="yz"/></td>
                </tr>
                <tr>
                    <td><div class="code" id="checkCode" onclick="createCode()" ></div></td>
                    <td width="173"><a  href="#" onclick="createCode()">看不清换一张</a></td>
                </tr>
                <tr>
                    <td colspan="2" align="center"><input id="Button1"  onclick="validateCode();" type="submit" name="Submit" value="注册" />
                    </td>
                </tr>
            </table>
        </form>
        </div>
     </div>
</div>
</body>
</html>