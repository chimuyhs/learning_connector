<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>无标题文档</title>
</head>

<body>
<?php
		include("conn.php");
		$user = $_POST["username"];
		$pwd = $_POST["password"];
		if($user == "" || $pwd == "")
		{
			echo "<script>alert('请输入用户名或密码！'); history.go(-1);</script>";
		}
		else
		{
			$sql = mysqli_query($conn,"select * from tb_zhanghu where username='$user' and password='$pwd' ");
			if(mysqli_num_rows($sql)>0){
				echo"<script>alert('登陆成功');location='index.php';</script>";
			}
			else{
				echo"<script>alert('用户名或密码错误');history.go(-1);</script>";
				}
		}
?>
</body>
</html>